(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_daddfccc._.js",
  "static/chunks/86575_next_dist_compiled_react-dom_4bd23ae4._.js",
  "static/chunks/86575_next_dist_compiled_react-server-dom-turbopack_214d4b51._.js",
  "static/chunks/86575_next_dist_compiled_next-devtools_index_fdb1ceed.js",
  "static/chunks/86575_next_dist_compiled_589eb25c._.js",
  "static/chunks/86575_next_dist_client_d139c6dc._.js",
  "static/chunks/86575_next_dist_73c2c41b._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
