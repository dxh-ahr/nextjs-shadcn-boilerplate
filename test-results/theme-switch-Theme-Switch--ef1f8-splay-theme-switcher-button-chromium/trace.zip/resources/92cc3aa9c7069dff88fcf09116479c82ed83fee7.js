(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_b1c96180._.js",
  "static/chunks/_5c68ba71._.js",
  "static/chunks/[root-of-the-server]__077fd7b5._.css"
],
    source: "dynamic"
});
